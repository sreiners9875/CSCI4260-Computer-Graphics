class RayTracedObject{
  constructor(geometry, shader){
    this.geometry = geometry
    this.shader = shader;
  }
}