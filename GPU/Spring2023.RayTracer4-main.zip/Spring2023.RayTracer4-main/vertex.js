class Vertex{
  constructor(position, uv, normal){
    this.position = position;
    this.uv = uv;
    this.normal = normal;
  }
}