# Ray Tracer 
## Created for CS4620, Spring 2023, the University of Nebraska at Omaha

To comile the jsdoc, install jsdoc and run `jsdoc ray-tracer.js`